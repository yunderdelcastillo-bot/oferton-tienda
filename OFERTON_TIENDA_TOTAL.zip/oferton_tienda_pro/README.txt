OFERTÓN PRO — tienda virtual editable hasta 200 productos

Incluye:
- Catálogo con hasta 200 productos.
- Panel ⚙️ Admin en el navegador.
- Crear, editar y eliminar productos.
- Subir una imagen de cada producto desde el celular/computadora.
- Categorías, buscador, stock, código, precio, precio anterior, descripción y características.
- Carrito con cantidades y total.
- Pedido automático por WhatsApp 977 974 730.
- Sección de pago con Yape.
- Panel para cambiar número Yape y subir el QR real.
- Respaldo/restauración del catálogo en JSON.
- Diseño responsive inspirado en la referencia.

IMPORTANTE:
- El QR incluido es SOLO DE MUESTRA. Antes de vender, entra a Admin > Yape y sube tu QR real.
- Los productos adicionales se crean desde Admin > Productos.
- Los cambios del panel se guardan en el navegador del dispositivo. Para una tienda multiusuario con datos compartidos entre clientes necesitarías conectar una base de datos/backend.
- Para publicar en Internet, sube index.html y la carpeta assets a un hosting estático o servidor.
