OFERTÓN + IA — INSTALACIÓN

QUÉ HACE
1. Entra al panel ⚙️ Administración > Productos.
2. Sube la foto del producto.
3. Automáticamente la IA analiza la foto y rellena:
   - Nombre
   - Categoría
   - Título de oferta
   - Descripción
   - Características
   - Texto comercial para WhatsApp (queda disponible para ampliar el sistema)
4. El CÓDIGO/SKU también se genera automáticamente (OFE-CATEGORIA-PRODUCTO-XXXXX).
5. Tú solo revisas y completas precio, precio anterior y stock.
6. Guardas y el producto aparece en la tienda.

INSTALACIÓN EN PC
Requisitos: Node.js 20+.

1) Abre una terminal dentro de esta carpeta.
2) Ejecuta: npm install
3) Copia .env.example a .env
4) En .env coloca tu clave:
   OPENAI_API_KEY=tu_clave_real
5) Ejecuta: npm start
6) Abre: http://localhost:3000

IMPORTANTE
- NO pongas la clave de OpenAI dentro de index.html.
- La clave queda en el servidor (.env).
- La generación con IA consume créditos de tu cuenta de API.
- Revisa las características generadas antes de publicar; la IA puede equivocarse si la foto no muestra un dato.

YAPE
El QR real de Yape ya está incluido como assets/yape-qr.png.
Número configurado: 977 974 730.

WHATSAPP
Número configurado: 977 974 730.

NOTA SOBRE DATOS
Esta versión mantiene catálogo/configuración en localStorage del navegador. Para que los productos se guarden en la nube y puedas administrarlos desde varios celulares/computadoras, el siguiente paso es conectar una base de datos y almacenamiento (por ejemplo Supabase/Firebase).

AUTOMATIZACIÓN DE FOTOS
- Sube una sola foto en Administración > Productos.
- La IA genera la ficha y el código automáticamente.
- Pulsa “Generar 2 fotos adicionales con IA” para crear dos vistas nuevas del mismo producto.
- Se guardan 3 imágenes en la ficha: original + 2 vistas IA.
- Revisa siempre las imágenes generadas antes de publicar.
- Para activar IA, configura OPENAI_API_KEY en .env y ejecuta npm install && npm start.
- El servidor usa Responses API para texto/visión y gpt-image-2 para edición/generación de imágenes.
