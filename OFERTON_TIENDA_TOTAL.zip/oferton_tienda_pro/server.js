import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import OpenAI, { toFile } from 'openai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || 'gpt-6-luna';
const IMAGE_MODEL = process.env.OPENAI_IMAGE_MODEL || 'gpt-image-2';
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.use(express.json({ limit: '25mb' }));
app.use(express.static(__dirname));
app.get('/api/health', (_req, res) => res.json({ ok: true, ai: !!client, model: MODEL, imageModel: IMAGE_MODEL }));

function dataParts(dataUrl){
  const m=String(dataUrl).match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if(!m) throw new Error('Imagen no válida.');
  return {mime:m[1], buffer:Buffer.from(m[2],'base64')};
}

app.post('/api/analyze-product', async (req, res) => {
  try {
    if (!client) return res.status(500).json({ error: 'Falta OPENAI_API_KEY en el servidor.' });
    const image = req.body?.image; const {mime}=dataParts(image);
    const response = await client.responses.create({
      model: MODEL,
      input: [{ role:'user', content:[
        { type:'input_text', text:`Analiza esta foto de un producto para OFERTÓN (Perú). Crea una ficha comercial atractiva pero veraz. No inventes especificaciones que no se puedan ver o inferir razonablemente. Si hay texto visible, úsalo. Devuelve JSON con nombre, categoría (Hogar, Tecnología, Ropa, Belleza, Ofertas, Cocina u Otros), título de oferta, descripción, características, beneficios y mensaje de WhatsApp. El código/SKU lo genera la tienda.` },
        { type:'input_image', image_url:image, detail:'high' }
      ]}],
      text:{format:{type:'json_schema',name:'product_card',strict:true,schema:{type:'object',additionalProperties:false,properties:{name:{type:'string'},category:{type:'string',enum:['Hogar','Tecnología','Ropa','Belleza','Ofertas','Cocina','Otros']},offerTitle:{type:'string'},description:{type:'string'},features:{type:'array',items:{type:'string'}},benefits:{type:'array',items:{type:'string'}},whatsappText:{type:'string'}},required:['name','category','offerTitle','description','features','benefits','whatsappText']}}}
    });
    res.json(JSON.parse(response.output_text));
  } catch(err){ console.error(err); res.status(500).json({error:err?.message||'Error al analizar la imagen.'}); }
});

app.post('/api/generate-product-views', async (req,res)=>{
  try{
    if(!client) return res.status(500).json({error:'Falta OPENAI_API_KEY en el servidor.'});
    const image=req.body?.image; const {mime,buffer}=dataParts(image);
    const prompts=[
      'Create a photorealistic ecommerce product photo of the EXACT SAME PRODUCT shown in the reference image, viewed from a natural 3/4 side angle. Preserve the exact shape, colors, materials, controls, proportions and visible design. Clean professional white studio background, soft lighting, no hands, no extra objects, no text or logos added.',
      'Create a photorealistic ecommerce product photo of the EXACT SAME PRODUCT shown in the reference image, viewed from a slightly different rear/side angle that clearly shows another part of the product. Preserve the exact shape, colors, materials, controls, proportions and visible design. Clean professional white studio background, soft lighting, no hands, no extra objects, no text or logos added.'
    ];
    const images=[];
    for(const prompt of prompts){
      const out=await client.images.edit({model:IMAGE_MODEL,image:await toFile(buffer,'product.'+(mime.split('/')[1]||'png'),{type:mime}),prompt,size:'1024x1024',quality:'medium'});
      const b64=out.data?.[0]?.b64_json; if(!b64) throw new Error('La IA no devolvió una imagen.');
      images.push('data:image/png;base64,'+b64);
    }
    res.json({images});
  }catch(err){console.error(err);res.status(500).json({error:err?.message||'No se pudieron generar las vistas.'});}
});

app.get('/{*splat}', (_req,res)=>res.sendFile(path.join(__dirname,'index.html')));
app.listen(PORT,()=>console.log(`🚀 OFERTÓN listo en http://localhost:${PORT}`));
